Compile with Java 8.

Run Driver.

Follow input props.