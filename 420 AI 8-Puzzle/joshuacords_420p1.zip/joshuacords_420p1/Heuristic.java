
public interface Heuristic {
	public int cost(MyState myState);
}
