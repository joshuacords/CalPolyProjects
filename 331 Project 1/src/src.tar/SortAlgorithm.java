
public interface SortAlgorithm {
	void sort(double[] array);
}
