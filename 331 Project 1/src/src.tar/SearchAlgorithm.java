
public interface SearchAlgorithm {
	boolean search(double array[], double item);
}
