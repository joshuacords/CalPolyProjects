
public interface LocalSearch {

	NQueensState run();
	void setState(NQueensState state);

}