Compile all files under src into a java 8 project.

Enter n, iterations, and max-moves when prompted, program should execute and return results.